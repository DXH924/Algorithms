
public class QF extends Percolation{
	public QF(int N){
		super(N);
	}
}
